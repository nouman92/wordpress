<?php
/*
$subtitle_meta = new WPAlchemy_MetaBox(array
(
	'id' => '_subtitle_meta',
	'title' => 'Subtitle',
	'types' => array('page'), // added only for pages and to custom post type "events"
	'context' => 'normal', // same as above, defaults to "normal"
	'priority' => 'high', // same as above, defaults to "high"
	'template' => get_template_directory() . '/inc/metaboxes/pagesubtitle.php'
));

*/