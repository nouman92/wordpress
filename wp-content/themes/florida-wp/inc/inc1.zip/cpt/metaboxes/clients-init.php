<?php
/*
$clients_meta = new WPAlchemy_MetaBox(array
(
	'id' => '_clients_meta',
	'title' => 'Clients',
	'types' => array('clients'), // added only for pages and to custom post type "events"
	'context' => 'normal', // same as above, defaults to "normal"
	'priority' => 'high', // same as above, defaults to "high"
	'template' => get_template_directory() . '/inc/cpt/metaboxes/clients.php'
));
 * 
 */
