<?php

vc_map( array(
        "name" =>"Webnus Iconbox",
        "base" => "iconbox",
        "description" => "Icon + text article",
		"icon" => "icon-wpb-wiconbox",
        "category" => __( 'Webnus Shortcodes', 'WEBNUS_TEXT_DOMAIN' ),
        "params" => array(
            array(
                "type" => "dropdown",
                "heading" => __( "IconBox Type", 'WEBNUS_TEXT_DOMAIN' ),
                "param_name" => "type",
                "value" => array(
				"Type 0"=>'0',
				"Type 1"=>'1',
				"Type 2"=>'2',
				"Type 3"=>'3',
				"Type 4"=>'4',
				"Type 5"=>'5',
				"Type 6"=>'6',
				"Type 7"=>'7'
				),
                "description" => __( "Select Iconbox Type", 'WEBNUS_TEXT_DOMAIN')
            ),
             array(
				"type"=>'textfield',
				"heading"=>__('Title', 'WEBNUS_TEXT_DOMAIN'),
				"param_name"=> "icon_title",
				"value"=>"",
				"description" => __( "Icon size in px format, Example: 16px", 'WEBNUS_TEXT_DOMAIN')
				
			),
            array(
				"type"=>'textarea',
				"heading"=>__('IconBox Content', 'WEBNUS_TEXT_DOMAIN'),
				"param_name"=> "content",
				"value"=>"",
				"description" => __( "IconBox Content Goes Here", 'WEBNUS_TEXT_DOMAIN')
				
			),
			 array(
				"type"=>'textfield',
				"heading"=>__('IconBox Link URL', 'WEBNUS_TEXT_DOMAIN'),
				"param_name"=> "icon_link_url",
				"value"=>"",
				"description" => __( "IconBox Link URL (http://example.com)", 'WEBNUS_TEXT_DOMAIN'),
				
			),
			 array(
				"type"=>'textfield',
				"heading"=>__('IconBox Link Text', 'WEBNUS_TEXT_DOMAIN'),
				"param_name"=> "icon_link_text",
				"value"=>"",
				"description" => __( "IconBox Link Text", 'WEBNUS_TEXT_DOMAIN'),
				
			),
            array(
                "type" => "icomoon",
                "heading" => __( "IconBox Icon", 'WEBNUS_TEXT_DOMAIN' ),
                "param_name" => "icon_name",
                'value'=>'',
                "description" => __( "Select Iconbox Type", 'WEBNUS_TEXT_DOMAIN')
            ),
            array(
                "type" => "attach_image",
                "heading" => __( "IconBox Image Icon", 'WEBNUS_TEXT_DOMAIN' ),
                "param_name" => "icon_image",
                'value'=>'',
                "description" => __( "Select Iconbox Image", 'WEBNUS_TEXT_DOMAIN')
            ),
			
            array(
				"type"=>'textfield',
				"heading"=>__('Icon Size(leave blank for default size)', 'WEBNUS_TEXT_DOMAIN'),
				"param_name"=> "icon_size",
				"value"=>"",
				"description" => __( "Icon size in px format, Example: 16px", 'WEBNUS_TEXT_DOMAIN')
				
			),
			array(
				"type"=>'colorpicker',
				"heading"=>__('Icon color(leave bank for default color)', 'WEBNUS_TEXT_DOMAIN'),
				"param_name"=> "icon_color",
				"value"=>"",
				"description" => __( "Select icon color", 'WEBNUS_TEXT_DOMAIN')
				
			),
			
           
        ),
		
        
    ) );


?>