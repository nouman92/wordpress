<?php

vc_map( array(
        'name' =>'Webnus Clear',
        'base' => 'clear',
		"description" => "Clear fix",
        'show_settings_on_create'=>false,
        "icon" => "icon-wpb-wclear",
        'category' => __( 'Webnus Shortcodes', 'WEBNUS_TEXT_DOMAIN' ),
    ) );


?>