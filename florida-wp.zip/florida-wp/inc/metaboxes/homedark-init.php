<?php
/*
$homedark_options_meta = new WPAlchemy_MetaBox(array
(
	'id' => '_homedark',
	'title' => 'Dark Half Page Options',
	'types' => array('page'),
	
	'template' => get_template_directory() . '/inc/metaboxes/homedark.php',
		
));
*/
?>
