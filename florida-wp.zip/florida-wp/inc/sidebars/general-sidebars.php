<?php

/******************************/
/*
/*		Register Widgets
/*
/******************************/


function webnus_sidebar_init() {
	register_sidebar( array(
		'name'          => __( 'Left Sidebar', 'WEBNUS_TEXT_DOMAIN' ),
		'id'            => 'left-sidebar',
		'description'   => __( 'Appears in left side in the blog page.', 'WEBNUS_TEXT_DOMAIN' ),
		'before_widget' => '<div class="widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="subtitle">',
		'after_title'   => '</h4>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Right Sidebar', 'WEBNUS_TEXT_DOMAIN' ),
		'id'            => 'right-sidebar',
		'description'   => __( 'Appears in right side in the blog page.', 'WEBNUS_TEXT_DOMAIN' ),
		'before_widget' => '<div class="widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="subtitle">',
		'after_title'   => '</h4>',
	) );
		
	register_sidebar(array(
    'name' => 'Home Slider',
    'before_widget' => '',
    'after_widget' => '',
	));

	
	
	register_sidebar( array(
		'name'          => __( 'Footer Section 1', 'WEBNUS_TEXT_DOMAIN' ),
		'id'            => 'footer-section-1',
		'description'   => __( 'Appears in footer section 1', 'WEBNUS_TEXT_DOMAIN' ),
		'before_widget' => '<div class="widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h5 class="subtitle">',
		'after_title'   => '</h5>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Section 2', 'WEBNUS_TEXT_DOMAIN' ),
		'id'            => 'footer-section-2',
		'description'   => __( 'Appears in footer section 2', 'WEBNUS_TEXT_DOMAIN' ),
		'before_widget' => '<div class="widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h5 class="subtitle">',
		'after_title'   => '</h5>',
	) );

	
	register_sidebar( array(
		'name'          => __( 'Footer Section 3', 'WEBNUS_TEXT_DOMAIN' ),
		'id'            => 'footer-section-3',
		'description'   => __( 'Appears in footer section 3', 'WEBNUS_TEXT_DOMAIN' ),
		'before_widget' => '<div class="widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h5 class="subtitle">',
		'after_title'   => '</h5>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Section 4', 'WEBNUS_TEXT_DOMAIN' ),
		'id'            => 'footer-section-4',
		'description'   => __( 'Appears in footer section 4', 'WEBNUS_TEXT_DOMAIN' ),
		'before_widget' => '<div class="widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h5 class="subtitle">',
		'after_title'   => '</h5>',
	) );



	  register_sidebar( array(
		'name' => __( 'WooCommerce Page Sidebar', 'WEBNUS_TEXT_DOMAIN' ),
		'id' => 'shop-widget-area',
		'description' => __( 'Product page widget area', 'WEBNUS_TEXT_DOMAIN' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title"><span>',
		'after_title' => '</span></h3><div class="sidebar-line"><span></span></div>',
	) );
	
	register_sidebar( array(
		'name' => __( 'Header Ad Sidebar', 'WEBNUS_TEXT_DOMAIN' ),
		'id' => 'header-advert',
		'description' => __( 'Header Advertisement Sidebar', 'WEBNUS_TEXT_DOMAIN' ),
		'before_widget' => '<div class="widget">',
		'after_widget' => '</div>',
		'before_title' => '<h5 class="subtitle">',
		'after_title' => '</h5>',
	) );
}
add_action( 'widgets_init', 'webnus_sidebar_init' );

?>