<?php

 $TConfig = array(
	'access_token' => "270779417-xCVhjXQR3gV9PNmfcnzffjhGTycvFEwAnO9io0PH",
	'access_token_secret'  => "dfKoHqY8PzISqpAftcEC6PrQ4NFTDmOxKKGJEgFyuVU",
	'consumer_key'  => "OjpnVleJXlSkWXO1FOtVRw",
	'consumer_secret' => "zE9oX9p7XLjJWyrWlsE0XFgLihRAPUmQPToPWimAT8",

	'screen_name'       => 'webnus',
	'count'             => 1
);
?>