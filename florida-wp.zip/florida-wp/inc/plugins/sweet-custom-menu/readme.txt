=== Sweet Custom Menu ===
Author URI: http://remicorson/
Plugin URI: http://remicorson.com/sweet-custom-menu
Contributors: corsonr
Donate link: http://remicorson.com/
Tags: Remi Corson, corsonr, menu, wordpress menu, wp_nav_menu
Requires at least: 3.0
Tested up to: 3.5
Stable Tag: 0.1

This is a simple plugin to add custom attributes to WordPress menus.

== Description ==

This is a simple plugin to add custom attributes to WordPress menus. This plugin is a working plugin but should be used as an example to implement your custom menu fields. The creation of this plugin is explained [here](http://wpexplorer.com/adding-custom-attributes-to-wordpress-menus)

If you have suggestions or bugfixes for the plugin, please report them on [my website](http://remicorson.com).

**Languages**

This plugin has been translated into the following languages:

1. English

If you want to translate the plugin into your language, [contact me](http://remicorson/contact).

== Installation ==

1. Activate the plugin
2. Go to Appearance > Menus
3. Fill in the "subtitle" field
4. Open header.php in your theme folder
5. Search wp_nav_menu() function
6. Add walker parameter: 'walker' => 'rc_scm_walker'


== Screenshots ==

1. Add custom fields to your menus


== Changelog ==

= 0.1 =

* First release!

== Upgrade Notice ==

= 0.1 =

* First release!