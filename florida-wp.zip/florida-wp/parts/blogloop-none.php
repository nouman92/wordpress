<h1>
<?php _e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'WEBNUS_TEXT_DOMAIN' ); 
?>
<br class="clear"/>
<br class="clear"/>
<?php
get_search_form();
?>
</h1>