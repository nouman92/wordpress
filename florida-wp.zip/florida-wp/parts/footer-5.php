<div class="col-md-6">
<?php dynamic_sidebar('footer-section-1'); ?>
</div>
<div class="col-md-6">
<?php dynamic_sidebar('footer-section-2'); ?>
</div>
