<div class="col-md-4"><?php dynamic_sidebar('footer-section-1'); ?></div>
<div class="col-md-4"><?php dynamic_sidebar('footer-section-2'); ?></div>
<div class="col-md-4"><?php dynamic_sidebar('footer-section-3'); ?></div>